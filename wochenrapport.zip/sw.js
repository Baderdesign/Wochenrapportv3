/* Service Worker: damit die App auch ohne Netz startet. Liegt im selben Ordner wie index.html. */
var CACHE = "wochenrapport-v2-1";
var LIBS = [
  "https://cdnjs.cloudflare.com/ajax/libs/jspdf/2.5.1/jspdf.umd.min.js",
  "https://cdn.jsdelivr.net/npm/@supabase/supabase-js@2.45.4/dist/umd/supabase.min.js"
];
self.addEventListener("install", function (e) {
  self.skipWaiting();
  e.waitUntil(caches.open(CACHE).then(function (c) {
    return Promise.all(LIBS.map(function (u) {
      return fetch(new Request(u, { mode: "no-cors" })).then(function (r) { return c.put(u, r); }).catch(function () { });
    }));
  }));
});
self.addEventListener("activate", function (e) {
  e.waitUntil(caches.keys().then(function (ks) {
    return Promise.all(ks.filter(function (k) { return k !== CACHE; }).map(function (k) { return caches.delete(k); }));
  }).then(function () { return self.clients.claim(); }));
});
self.addEventListener("fetch", function (e) {
  var req = e.request;
  if (req.method !== "GET") return;
  var url = new URL(req.url);
  if (url.origin === self.location.origin) {
    /* eigene Seite: zuerst Netz (aktuell), sonst gespeicherte Kopie */
    e.respondWith(fetch(req).then(function (r) {
      var copy = r.clone(); caches.open(CACHE).then(function (c) { c.put(req, copy); }); return r;
    }).catch(function () { return caches.match(req, { ignoreSearch: true }); }));
  } else if (LIBS.indexOf(req.url) >= 0) {
    /* PDF- und Cloud-Bibliothek: zuerst gespeicherte Kopie */
    e.respondWith(caches.match(req).then(function (m) {
      return m || fetch(req).then(function (r) { var copy = r.clone(); caches.open(CACHE).then(function (c) { c.put(req, copy); }); return r; });
    }));
  }
});
